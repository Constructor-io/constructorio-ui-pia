import DOMPurify from 'dompurify';
export interface SanitizeOptions {
    config: DOMPurify.Config;
}
/** Options for {@link renderMarkdown}. */
export interface RenderMarkdownOptions {
    /**
     * Override the default DOMPurify sanitization step.
     * Called with an isolated DOMPurify instance, the parsed HTML string,
     * and an options object containing the default config. Must return the sanitized HTML string.
     *
     * @example
     * sanitize: (purifier, html, { config }) => {
     *   purifier.addHook('uponSanitizeAttribute', (node, event) => {
     *     if (node.tagName === 'A' && event.attrName === 'href') {
     *       if (/^javascript:window\.openChat\(\)$/.test(event.attrValue)) {
     *         event.forceKeepAttr = true;
     *       }
     *     }
     *   });
     *   return purifier.sanitize(html, config);
     * }
     */
    sanitize?: (purifier: typeof DOMPurify, html: string, options: SanitizeOptions) => string;
}
export declare function sanitizeHtml(html: string): string;
export declare function renderMarkdown(content: string, options?: RenderMarkdownOptions): string;
