/**
 * This file is generated automatically, using our "compile" action.
 * @see {@link ../.github/actions/compile/action.yml}
 */
declare const _default: "1.2.0";
export default _default;
