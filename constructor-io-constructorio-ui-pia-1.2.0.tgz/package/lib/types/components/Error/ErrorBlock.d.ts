import React from 'react';
import { Translations } from '../../types';
interface ErrorBlockProps {
    message: string;
    onRetry?: () => void;
    translations?: Translations;
    /**
     * Whether the message is a `role='alert'` live region. Turn off when the block is rendered
     * inside another live region (such as the conversation `role='log'`), which already announces
     * inserted text: nesting the two would announce the error twice. Defaults to true.
     */
    announce?: boolean;
}
declare function ErrorBlock({ message, onRetry, translations, announce, }: ErrorBlockProps): React.JSX.Element;
export default ErrorBlock;
