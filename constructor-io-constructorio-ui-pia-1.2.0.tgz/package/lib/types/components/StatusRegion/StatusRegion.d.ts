import React from 'react';
import { Translations } from '../../types';
interface StatusRegionProps {
    message: string;
    'data-testid'?: string;
}
/**
 * Visually hidden `role='status'`. Keep it mounted and change only `message`:
 * a live region created together with its text is announced inconsistently.
 */
export default function StatusRegion({ message, 'data-testid': testId }: StatusRegionProps): React.JSX.Element;
export declare function answerStatusMessage(isLoading: boolean, hasAnswer: boolean, translations?: Translations): string;
export {};
