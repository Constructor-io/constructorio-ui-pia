import React from 'react';
import { FeedbackType, Item, Question } from '../../types';
import { ConversationHistoryProps } from '../ConversationHistory/ConversationHistory';
export interface PiaConversationProps extends ConversationHistoryProps {
    displayedQuestions: Question[];
    handleSubmitQuestion: (question: string) => void;
    handleQuestionClick: (question: string) => void;
    containerRef?: (node: HTMLDivElement | null) => void;
    handleFeedback?: (type: FeedbackType) => void;
    onResultClick?: (item: Item, position: number, question: string, qnaResultId?: string) => void;
    qnaResultId?: string;
    onInputFocus?: () => void;
}
export default function PiaConversation({ conversationHistory, isLoading, error, currentItems, showFeedback, showPreviousItems, learnMoreUrl, disclaimerPosition, translations, callbacks, componentOverrides, displayedQuestions, handleSubmitQuestion, handleQuestionClick, containerRef, handleFeedback, onResultClick, qnaResultId, onInputFocus, priceCurrency, }: PiaConversationProps): React.JSX.Element;
