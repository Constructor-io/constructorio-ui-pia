import React from 'react';
import { ConversationEntry, FeedbackType, Translations, Item, Callbacks, CioPiaComponentOverrides, DisclaimerPosition } from '../../types';
export interface ConversationHistoryProps {
    conversationHistory: ConversationEntry[];
    isLoading: boolean;
    /**
     * Whether the answer request itself is in flight. `isLoading` also covers the follow-up
     * questions request, which is fine for the visible skeleton but would make the status region
     * announce "Loading answer" while only the questions are loading. Defaults to `isLoading`.
     */
    isAnswerLoading?: boolean;
    error: Error | null;
    /**
     * Items for the latest conversation entry's carousel.
     * - `undefined` (not provided): falls back to entry.items
     * - `null`: explicitly no items, hides the carousel
     * - `Item[]`: shows these items, overriding entry.items
     */
    currentItems?: Item[] | null;
    showFeedback?: boolean;
    /**
     * Show product carousels on non-last conversation entries. Defaults to true.
     * The last entry always falls back to its own items when currentItems is not provided.
     */
    showPreviousItems?: boolean;
    learnMoreUrl?: string;
    disclaimerPosition?: DisclaimerPosition;
    translations?: Translations;
    callbacks?: Callbacks;
    componentOverrides?: CioPiaComponentOverrides;
    handleFeedback?: (type: FeedbackType) => void;
    onResultClick?: (item: Item, position: number, question: string, qnaResultId?: string) => void;
    qnaResultId?: string;
    priceCurrency?: string;
}
export default function ConversationHistory({ conversationHistory, isLoading, isAnswerLoading, error, currentItems, showFeedback, showPreviousItems, learnMoreUrl, disclaimerPosition, translations, callbacks, componentOverrides, handleFeedback, onResultClick, qnaResultId, priceCurrency, }: ConversationHistoryProps): React.JSX.Element;
