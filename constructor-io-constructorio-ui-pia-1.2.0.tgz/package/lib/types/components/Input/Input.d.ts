import React from 'react';
import { ComponentOverrideProps } from '@constructor-io/constructorio-ui-components';
import { InputRenderProps, Translations } from '../../types';
interface InputProps {
    value?: string;
    disabled?: boolean;
    /** @deprecated Use the `translations` prop instead. */
    placeholder?: string;
    onSubmit: (value: string) => void;
    onFocus?: () => void;
    translations?: Translations;
    componentOverride?: ComponentOverrideProps<InputRenderProps>;
    error?: string;
    placeholderKey?: string;
    /**
     * Render the Send button after the field.
     *
     * @default true
     */
    showSendButton?: boolean;
}
declare function Input({ value: providedValue, placeholder, disabled, onSubmit, onFocus, translations, componentOverride, error, placeholderKey, showSendButton, }: InputProps): React.JSX.Element;
export default Input;
