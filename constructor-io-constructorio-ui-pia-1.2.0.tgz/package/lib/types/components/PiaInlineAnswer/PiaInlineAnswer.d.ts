import React from 'react';
import { Callbacks, CioPiaComponentOverrides, DisclaimerPosition, FeedbackType, Translations, Item } from '../../types';
interface PiaInlineAnswerProps {
    currentAnswer: string;
    currentItems: Item[] | null;
    showFeedback?: boolean;
    learnMoreUrl?: string;
    disclaimerPosition?: DisclaimerPosition;
    translations?: Translations;
    callbacks?: Callbacks;
    componentOverrides?: CioPiaComponentOverrides;
    onFeedback?: (type: FeedbackType) => void;
    onResultClick?: (item: Item, position: number, question: string, qnaResultId?: string) => void;
    question?: string;
    qnaResultId?: string;
    priceCurrency?: string;
}
export default function PiaInlineAnswer({ currentAnswer, currentItems, showFeedback, learnMoreUrl, disclaimerPosition, translations, callbacks, componentOverrides, onFeedback, onResultClick, question, qnaResultId, priceCurrency, }: PiaInlineAnswerProps): React.JSX.Element;
export {};
