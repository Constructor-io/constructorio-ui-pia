import React from 'react';
import { ComponentOverrideProps } from '@constructor-io/constructorio-ui-components';
import { LoadingRenderProps } from '../../types';
interface RecsCarouselSkeletonProps {
    /** How many cards to draw. Defaults to the widest band the carousel lays out. */
    count?: number;
    componentOverride?: ComponentOverrideProps<LoadingRenderProps>;
}
/**
 * The product row, greyed out. It uses the real carousel rather than a set of measurements copied
 * out of the package, so its padding, its gaps, how many cards it fits at the current width and its
 * arrows are all right by construction. Matching the real heights is what keeps the page from
 * jumping when the data lands.
 */
export default function RecsCarouselSkeleton({ count, componentOverride, }: RecsCarouselSkeletonProps): React.JSX.Element;
export {};
