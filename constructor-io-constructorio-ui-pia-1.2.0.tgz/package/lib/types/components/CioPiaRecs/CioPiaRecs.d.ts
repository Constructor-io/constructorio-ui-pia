import React from 'react';
import type { CioPiaProps } from '../CioPia/types';
/**
 * A pod of AI-curated product suggestions: a personalized title, a row of products, and short
 * options for narrowing them down. It asks no questions and makes no Q&A requests, so a retailer
 * can use it on its own.
 *
 * Renders nothing at all once a request has settled with no products, so whatever the retailer
 * already had in that slot shows through instead of an empty shell. That is the default: a caller
 * that supplied its own root — `children` or `componentOverrides.reactNode` — still gets it in that
 * state, with `error` available, and decides what belongs there.
 */
export default function CioPiaRecs(props: CioPiaProps): React.JSX.Element | null;
