import React from 'react';
import { CioPiaComponentOverrides, RecsRefinement, Translations } from '../../types';
interface RecsPodRefinementProps {
    refinement: RecsRefinement | null;
    isLoading: boolean;
    /** Message for a value the shopper submitted that came back rejected. */
    inputError: string | null;
    showInput: boolean;
    translations?: Translations;
    componentOverrides?: CioPiaComponentOverrides;
    onRefine: (text: string) => void;
    onSubmit: (value: string) => void;
    onInputFocus: () => void;
}
/**
 * The row under the products: a prompt line, the short options the API suggested, and a box for
 * anything it did not think of. The prompt line is held still while the rest reloads, so the row
 * never changes height under the shopper's cursor.
 */
export default function RecsPodRefinement({ refinement, isLoading, inputError, showInput, translations, componentOverrides, onRefine, onSubmit, onInputFocus, }: RecsPodRefinementProps): React.JSX.Element;
export {};
