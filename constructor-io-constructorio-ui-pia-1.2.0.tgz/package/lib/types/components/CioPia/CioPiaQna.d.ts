import React from 'react';
import type { CioPiaProps } from './types';
/** The question-and-answer experience: `mode: 'default'`, `mode: 'conversation'`, and the modal. */
export default function CioPiaQna(props: CioPiaProps): React.JSX.Element;
