import React from 'react';
import type { CioPiaProps } from './types';
export default function CioPia(props: CioPiaProps): React.JSX.Element;
