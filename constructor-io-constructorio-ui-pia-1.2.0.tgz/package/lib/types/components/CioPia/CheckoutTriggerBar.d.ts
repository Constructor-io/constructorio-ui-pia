import React from 'react';
import { CioPiaRenderProps } from '../../types';
import { translate } from '../../utils/translate';
import type { CheckoutTrigger } from './types';
interface CheckoutTriggerBarProps {
    triggers: CheckoutTrigger[];
    state: CioPiaRenderProps;
    translations?: Parameters<typeof translate>[1];
}
export default function CheckoutTriggerBar({ triggers, state, translations, }: CheckoutTriggerBarProps): React.JSX.Element | null;
export {};
