import React from 'react';
import { CarouselOverrides } from '@constructor-io/constructorio-ui-components';
import { Callbacks, Item, Translations } from '../../types';
interface PiaCustomCarouselProps {
    items: Array<Item>;
    componentOverrides?: CarouselOverrides<Item>;
    callbacks?: Callbacks;
    onResultClick?: (item: Item, position: number, question: string, qnaResultId?: string) => void;
    question?: string;
    qnaResultId?: string;
    translations?: Translations;
    priceCurrency?: string;
}
export default function PiaCustomCarousel({ items, componentOverrides, callbacks, onResultClick, question, qnaResultId, translations, priceCurrency, }: PiaCustomCarouselProps): React.JSX.Element | null;
export {};
