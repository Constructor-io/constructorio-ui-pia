import React from 'react';
export default function SendIcon(): React.JSX.Element;
