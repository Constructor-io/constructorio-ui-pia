import React from 'react';
export default function QuestionIcon(): React.JSX.Element;
