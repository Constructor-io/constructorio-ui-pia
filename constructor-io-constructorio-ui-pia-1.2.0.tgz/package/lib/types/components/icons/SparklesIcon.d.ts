import React from 'react';
export default function SparklesIcon(): React.JSX.Element;
