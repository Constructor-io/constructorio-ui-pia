import React, { ReactNode } from 'react';
interface SuggestedQuestionProps {
    question: string;
    onClick?: () => void;
    /** Replaces the leading icon. Defaults to a question mark. */
    icon?: ReactNode;
}
declare function SuggestedQuestion({ question, onClick, icon }: SuggestedQuestionProps): React.JSX.Element;
export default SuggestedQuestion;
