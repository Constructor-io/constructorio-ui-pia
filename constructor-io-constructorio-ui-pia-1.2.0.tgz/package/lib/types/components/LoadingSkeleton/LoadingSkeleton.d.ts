import React from 'react';
import { ComponentOverrideProps } from '@constructor-io/constructorio-ui-components';
import { LoadingRenderProps } from '../../types';
interface LoadingSkeletonProps {
    componentOverride?: ComponentOverrideProps<LoadingRenderProps>;
}
export default function LoadingSkeleton({ componentOverride }?: LoadingSkeletonProps): React.JSX.Element;
export {};
