export declare const DEMO_API_KEY = "key_13TO6qN9H3BP3Wrn";
export declare const DEMO_ITEM_ID = "149100215";
export declare const DEMO_ITEM_NAME = "Ensure Original Nutrition Shake";
export declare const DEMO_QUESTION = "What is the nutritional content of this shake?";
export declare const DEMO_QUESTION_ALTERNATIVE_PRODUCTS = "What alternative products are available for this item?";
export declare const MOCK_QUESTIONS: {
    value: string;
}[];
export declare const DISCLAIMER_TEXT = "AI-generated answers aim to help, but they may occasionally miss details or be inaccurate. Double-check important information before purchasing.";
/**
 * Recommendations pod strings the API cannot supply, because in these states there is either
 * no response yet or no usable response at all. Everything else the pod shows comes from the
 * API. All five are `Translations` keys, so reference the constants instead of retyping the
 * literals - a mistyped key falls back to itself with no warning.
 */
export declare const RECS_LOADING_TITLE = "Adapting recommendations to your preference";
export declare const RECS_FALLBACK_TITLE = "Best selling products";
export declare const RECS_UNSUPPORTED_REQUEST = "Unsupported request, try a different feature.";
export declare const RECS_REFINEMENT_LABEL = "Not what you're looking for? Try:";
export declare const RECS_INPUT_PLACEHOLDER = "Describe something else...";
