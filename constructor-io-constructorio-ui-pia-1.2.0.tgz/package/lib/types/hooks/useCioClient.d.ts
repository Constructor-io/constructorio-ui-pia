import ConstructorIOClient, { ConstructorClientOptions, Nullable } from '@constructor-io/constructorio-client-javascript';
export type UseCioClientProps = {
    apiKey?: string;
    cioClient?: Nullable<ConstructorIOClient>;
    options?: Omit<ConstructorClientOptions, 'apiKey' | 'sendTrackingEvents' | 'version'>;
};
type UseCioClient = (props: UseCioClientProps) => Nullable<ConstructorIOClient> | never;
declare const useCioClient: UseCioClient;
export default useCioClient;
