import type { CioClient } from './usePiaClient';
import { Formatters, Item, RecsPodParameters, RecsRefinement, Translations } from '../types';
/**
 * What the shopper did to ask for this refinement.
 *
 * Worth distinguishing because a rejected request is only the shopper's business when the text
 * came from them. An option is a label the API itself suggested, so a rejection there is ours to
 * answer for, not something to flag under their input.
 */
export type RefinementSource = 'option' | 'input';
export interface UseRecsPodProps {
    itemId: string;
    variationId?: string;
    threadId?: string;
    cioClient?: CioClient;
    parameters?: RecsPodParameters;
    formatImageUrl?: Formatters['formatImageUrl'];
    translations?: Translations;
}
export interface UseRecsPodReturn {
    /** The title to show right now, already resolved for the current state. */
    title: string;
    /** The products to render, or `null` when there are none. Never an empty array. */
    items: Array<Item> | null;
    refinement: RecsRefinement | null;
    /** True while a request is in flight. */
    isLoading: boolean;
    /**
     * The failure behind the fallback title, for callers rendering their own error handling.
     * Only set for an outright failure: a degraded response (`status: 'partial'`) shows the fallback
     * title with `error` still null, because that response arrived and its products are usable.
     */
    error: Error | null;
    /** Message to show under the input when the text the shopper sent was rejected. */
    inputError: string | null;
    /** The text behind what is currently on screen. Empty when nothing has been refined. */
    lastShopperInput: string;
    /**
     * Fetches again, narrowed by `text`. Used by both the options and the free-text input, and
     * `source` is how a rejected request finds the right place to be reported.
     */
    refine: (text: string, source: RefinementSource) => void;
}
/**
 * Owns everything a recommendations pod shows: one request on mount, one on every refinement,
 * and the title that belongs to whichever of those is happening right now.
 *
 * The previous items are deliberately kept while a new request is in flight, so a refinement
 * swaps the products without collapsing the row they sit in. The title is the one thing that does
 * change, so the shopper can see the pod reacting to what they asked for.
 */
export default function useRecsPod({ itemId, variationId, threadId, cioClient, parameters, formatImageUrl, translations, }: UseRecsPodProps): UseRecsPodReturn;
