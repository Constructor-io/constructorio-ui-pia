import { Tracker } from '@constructor-io/constructorio-client-javascript/lib/types/constructorio';
import { AnswerRequestParameters, Formatters, SuggestedQuestionsParameters } from '../types';
import { UseAnswerResultsReturn } from './useAnswerResults';
import { CioClient } from './usePiaClient';
import { UseSuggestedQuestionsReturn } from './useSuggestedQuestions';
export type { CioClient };
export interface UseCioPiaProps {
    apiKey: string;
    itemId: string;
    variationId?: string;
    threadId?: string;
    cioClient?: CioClient;
    suggestedQuestionsParameters?: SuggestedQuestionsParameters;
    answerParameters?: AnswerRequestParameters;
    /**
     * @deprecated Use `answerParameters` and `suggestedQuestionsParameters` instead.
     *
     * Only the following keys are forwarded (snake_case or camelCase accepted):
     *
     * Suggested-questions endpoint:
     * - `num_results` / `numResults` → numResults
     * - `pre_filter_expression` / `preFilterExpression` → preFilterExpression (JSON-parsed if string)
     *
     * Answer endpoint:
     * - `guard` → guard
     * - `pre_filter_expression` / `preFilterExpression` → preFilterExpression (JSON-parsed if string)
     * - `fmt_options` / `fmtOptions` → fmtOptions (JSON-parsed if string)
     *
     * All other keys (e.g. `ef-*`) are silently dropped.
     * Typed parameters take precedence over values specified here.
     */
    parameters?: Record<string, string | number | boolean>;
    /** Define outside the component or wrap with useCallback to avoid unnecessary re-renders. */
    formatImageUrl?: Formatters['formatImageUrl'];
}
export interface UseCioPiaReturn {
    cioClient: {
        tracker: Tracker;
    };
    threadId: string;
    suggestedQuestions: UseSuggestedQuestionsReturn;
    answers: UseAnswerResultsReturn;
}
export default function useCioPia(props: UseCioPiaProps): UseCioPiaReturn;
