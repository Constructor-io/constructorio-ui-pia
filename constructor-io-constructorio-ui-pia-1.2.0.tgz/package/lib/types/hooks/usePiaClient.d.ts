import ConstructorIOClient from '@constructor-io/constructorio-client-javascript';
export type CioClient = InstanceType<typeof ConstructorIOClient>;
export interface UsePiaClientProps {
    apiKey: string;
    threadId?: string;
    cioClient?: CioClient;
}
export interface UsePiaClientReturn {
    cioClient: CioClient;
    threadId: string;
}
export default function usePiaClient({ apiKey, threadId: providedThreadId, cioClient: providedClient, }: UsePiaClientProps): UsePiaClientReturn;
