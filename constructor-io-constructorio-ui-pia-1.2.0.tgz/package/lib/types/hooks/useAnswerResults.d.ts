import { Nullable } from '@constructor-io/constructorio-client-javascript';
import { AnswerRequestParameters, Formatters, Item, GetAnswerResultsResponse } from '../types';
import type { CioClient } from './usePiaClient';
export interface UseAnswerResultsProps {
    itemId: string;
    variationId?: string;
    threadId?: string;
    cioClient: CioClient;
    parameters?: AnswerRequestParameters;
    formatImageUrl?: Formatters['formatImageUrl'];
}
export interface UseAnswerResultsReturn {
    data: Nullable<GetAnswerResultsResponse>;
    items: Array<Item> | null;
    isLoading: boolean;
    error: Error | null;
    getAnswer: (question: string) => void;
}
export default function useAnswerResults({ itemId, variationId, threadId, cioClient, parameters, formatImageUrl, }: UseAnswerResultsProps): UseAnswerResultsReturn;
