import { Tracker } from '@constructor-io/constructorio-client-javascript/lib/types/constructorio';
import { FeedbackType, Item, Question, GetAnswerResultsResponse } from '../types';
export interface TimeSpan {
    start: string;
    end: string;
}
export interface UseTrackingProps {
    cioClient?: {
        tracker: Tracker;
    };
    itemId: string;
    itemName: string;
    variationId?: string;
    threadId?: string;
}
export interface UseTrackingReturn {
    trackViews: (questions: Question[], viewTimespans: TimeSpan[]) => void;
    trackView: (questions: Question[]) => void;
    trackOutOfView: () => void;
    trackFocus: () => void;
    trackQuestionClick: (question: string) => void;
    trackQuestionSubmit: (question: string) => void;
    trackAnswerView: (question: string, answerData: GetAnswerResultsResponse, items?: Item[] | null) => void;
    trackAnswerFeedback: (feedbackType: FeedbackType, qnaResultId?: string) => void;
    trackResultClick: (clickedItem: Item, position: number, question: string, qnaResultId?: string) => void;
}
export default function useTracking({ cioClient, itemId, itemName, variationId, threadId, }: UseTrackingProps): UseTrackingReturn;
