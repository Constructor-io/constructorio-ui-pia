import { Question } from '../types';
import { UseTrackingReturn } from './useTracking';
export interface UseViewportTrackingProps {
    tracking: UseTrackingReturn;
    questions: Question[];
    viewThreshold?: number;
}
export interface UseViewportTrackingReturn {
    containerRef: (node: HTMLDivElement | null) => void;
}
export default function useViewportTracking({ tracking, questions, viewThreshold, }: UseViewportTrackingProps): UseViewportTrackingReturn;
