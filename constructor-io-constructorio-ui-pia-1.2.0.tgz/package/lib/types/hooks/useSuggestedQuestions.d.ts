import { Question, SuggestedQuestionsParameters } from '../types';
import type { CioClient } from './usePiaClient';
export interface UseSuggestedQuestionsProps {
    itemId: string;
    variationId?: string;
    threadId?: string;
    cioClient?: CioClient;
    parameters?: SuggestedQuestionsParameters;
}
export interface UseSuggestedQuestionsReturn {
    data: Array<Question>;
    isLoading: boolean;
    error: Error | null;
    getSuggestedQuestions: () => void;
}
export default function useSuggestedQuestions({ itemId, variationId, threadId, cioClient, parameters, }: UseSuggestedQuestionsProps): UseSuggestedQuestionsReturn;
