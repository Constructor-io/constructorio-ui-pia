import { ReactNode } from 'react';
import { Product, CarouselOverrides, ComponentOverrideProps } from '@constructor-io/constructorio-ui-components';
import { ConstructorClientOptions, FilterExpression, ItemData, Nullable } from '@constructor-io/constructorio-client-javascript';
import type { CioClient } from './hooks/usePiaClient';
export declare enum FeedbackType {
    UP = "up",
    DOWN = "down"
}
export interface PiaContextValue {
    cioClient: Nullable<CioClient>;
    cioClientOptions: CioClientOptions;
    setCioClientOptions: React.Dispatch<CioClientOptions>;
    itemId: string;
    variationId?: string;
    /** Thread ID for conversation context. Must be a valid UUID (e.g., "550e8400-e29b-41d4-a716-446655440000") */
    threadId?: string;
}
export type CioClientOptions = Omit<ConstructorClientOptions, 'apiKey' | 'sendTrackingEvents'>;
export interface CioPiaProviderProps {
    apiKey: string;
    itemId: string;
    variationId?: string;
    /** Thread ID for conversation context. Must be a valid UUID (e.g., "550e8400-e29b-41d4-a716-446655440000") */
    threadId?: string;
    cioClient?: Nullable<CioClient>;
}
export type CioPiaMode = 'default' | 'conversation' | 'recommendations';
export type CioPiaType = 'inline' | 'modal';
export type DisclaimerPosition = 'top' | 'bottom';
export type CioPiaTrackingConfigs = {
    /**
     * Fraction of the container (0–1) that must be visible before the
     * `product_insights_agent.view` event fires. Defaults to `0.5`.
     */
    viewThreshold?: number;
};
export type CioPiaDisplayConfigs = {
    learnMoreUrl?: string;
    showFeedback?: boolean;
    mode?: CioPiaMode;
    type?: CioPiaType;
    /**
     * Show product carousels on non-last conversation entries. Defaults to true.
     * The last entry always falls back to its own items when currentItems is not provided.
     */
    showPreviousItems?: boolean;
    /**
     * Position of the AI disclaimer message relative to the conversation content.
     * - `'top'` — renders the disclaimer above the conversation history or answer.
     * - `'bottom'` — renders the disclaimer below the conversation history or answer.
     *
     * @default 'bottom'
     */
    disclaimerPosition?: DisclaimerPosition;
};
/**
 * Translations type for internationalizing UI strings.
 * All keys are optional - any non-provided translation will fallback to English default.
 */
export type Translations = {
    'Any questions about this product?'?: string;
    'Ask anything'?: string;
    /** Accessible name of the question field when its placeholder is blanked out. */
    'Your question'?: string;
    Send?: string;
    'AI-generated answers aim to help, but they may occasionally miss details or be inaccurate. Double-check important information before purchasing.'?: string;
    'Is this answer useful?'?: string;
    'Learn More.'?: string;
    'Ask about this product'?: string;
    'Add to Cart'?: string;
    'Unexpected error'?: string;
    'thumbs up'?: string;
    'thumbs down'?: string;
    Close?: string;
    Retry?: string;
    'Conversation history'?: string;
    'Loading answer'?: string;
    'Answer ready'?: string;
    /** Recommendations pod title shown while a request is in flight. */
    'Adapting recommendations to your preference'?: string;
    /** Recommendations pod title shown when a request fails or comes back degraded. */
    'Best selling products'?: string;
    /** Shown under the recommendations pod input when the request was rejected as unsuitable. */
    'Unsupported request, try a different feature.'?: string;
    /** Introduces the recommendations pod refinement options when the API sends no prompt of its own. */
    "Not what you're looking for? Try:"?: string;
    /** Placeholder for the recommendations pod refinement input. */
    'Describe something else...'?: string;
};
export type QuestionSource = 'user' | 'suggestion';
export interface PiaCallbackContext {
    itemId: string;
    threadId: string;
}
export interface Callbacks {
    /** Called when a question is submitted (typed or suggested question clicked). */
    onQuestionSubmit?: (question: string, context: PiaCallbackContext, source: QuestionSource) => void;
    /** Called when a product card in the carousel is clicked. */
    onProductCardClick?: (item: Item) => void;
    /**
     * Called when the "Add to Cart" button on a product card is clicked.
     * Providing this callback is what renders the button.
     * Clicking the button does not fire `onProductCardClick`.
     */
    onAddToCart?: (item: Item, event: React.MouseEvent) => void;
    /** Called when the user submits positive or negative feedback on an answer. */
    onFeedback?: (type: FeedbackType) => void;
    /** Called when a new answer is received. Passes the full conversation history. */
    onAnswer?: (history: ConversationEntry[], context: PiaCallbackContext) => void;
    /** Called when the user focuses the input field. */
    onFocus?: (context: PiaCallbackContext) => void;
    /** Called when the widget enters the viewport. */
    onView?: (context: PiaCallbackContext) => void;
    /** Called when the widget leaves the viewport. */
    onOutOfView?: (context: PiaCallbackContext) => void;
}
/** Formatter functions for transforming data before display. */
export interface Formatters {
    /** Transforms image URLs before rendering (e.g., prepend a CDN base URL). */
    formatImageUrl?: (url: string) => string;
}
/** Props forwarded to the ProductCard rendered inside the carousel. */
export interface ProductCardDisplayProps {
    /**
     * Currency symbol to display next to product prices (e.g., "€", "£").
     * When omitted, the default ProductCard price rendering is used.
     */
    priceCurrency?: string;
}
/** Extends Product type to include PIA-specific fields */
export interface Item extends Product, Record<string, any> {
    url?: string;
    matchedTerms?: string[];
}
export interface ConversationEntry {
    id: number;
    question: string;
    answer: string;
    source: QuestionSource;
    items?: Item[] | null;
    threadId?: string;
    qnaResultId?: string;
}
/** Which kind of recommendations to fetch. */
export type RecsStrategy = 'complementary_items' | 'alternative_items' | 'bestsellers' | 'bundles' | 'buy_it_again' | 'recently_viewed_items' | 'visually_similar_items';
/** A prompt line plus the short labels the shopper can pick from to narrow the results. */
export interface RecsRefinement {
    /** Introduces the options. Falls back to a translatable default when absent. */
    question?: string;
    options: string[];
}
/** One recommendations response, in the shape the pod renders. */
export interface RecsResult {
    title: string;
    items: Item[] | null;
    refinement: RecsRefinement | null;
    resultId?: string;
    threadId?: string;
    /** `'partial'` means the response is degraded, but any items it carries are still usable. */
    status?: 'complete' | 'partial';
}
export interface RecsPodParameters {
    /**
     * Which kind of recommendations to fetch. Inert until the recommendations endpoint ships: it is
     * forwarded to `agent.getRecs`, which has nothing to send it to yet, so only a caller's own
     * `getRecs` acts on it today.
     *
     * @default 'complementary_items'
     */
    strategy?: RecsStrategy;
    /** Last-resort title, used when the API returns items but no title of its own. */
    defaultTitle?: string;
    /**
     * Render the free-text refinement input next to the refinement options.
     *
     * @default true
     */
    showInput?: boolean;
    /** How many products to request. */
    numResults?: number;
}
/** Arguments for one recommendations request. */
export interface GetRecsProps {
    itemId: string;
    variationId?: string;
    /** Thread ID for conversation context. Must be a valid UUID. */
    threadId?: string;
    /** @default 'complementary_items' */
    strategy?: RecsStrategy;
    /** Free text the shopper submitted to narrow the results. Absent on the first request. */
    shopperInput?: string;
    numResults?: number;
    /**
     * Applied while the raw results are converted to Items. It lives on the request rather than
     * in the component because the raw response shape is provisional, and keeping the conversion
     * behind this one call is what makes the endpoint swappable later.
     */
    formatImageUrl?: Formatters['formatImageUrl'];
}
/**
 * Render props passed to CioPia children function
 */
export interface CioPiaRenderProps {
    items: Item[] | null;
    isLoading: boolean;
    error?: Error | null;
    currentAnswer: string;
    currentQuestion: string;
    displayedQuestions: Question[];
    handleSubmitQuestion: (question: string) => void;
    conversationHistory: ConversationEntry[];
}
export interface AnswerRenderProps {
    text: string;
}
export interface SuggestedQuestionsRenderProps {
    questions: Question[];
    onQuestionClick: (question: string) => void;
}
export interface DisclaimerRenderProps {
    learnMoreUrl?: string;
    translations?: Translations;
}
export interface FeedbackRenderProps {
    translations?: Translations;
    onFeedback?: (type: FeedbackType) => void;
}
export interface LoadingRenderProps {
    skeleton: ReactNode;
}
/**
 * Render props passed to a custom Input override.
 */
export interface InputRenderProps {
    disabled: boolean;
    placeholder: string;
    onSubmit: (value: string) => void;
    onFocus?: () => void;
    translations?: Translations;
    /** Validation message for the value that was just submitted, when there is one. */
    error?: string;
}
/**
 * Component overrides for CioPia.
 * Allows customization of sub-components via reactNode or render props functions.
 */
export interface CioPiaComponentOverrides extends ComponentOverrideProps<CioPiaRenderProps> {
    carousel?: CarouselOverrides<Item>;
    answer?: ComponentOverrideProps<AnswerRenderProps>;
    input?: ComponentOverrideProps<InputRenderProps>;
    suggestedQuestions?: ComponentOverrideProps<SuggestedQuestionsRenderProps>;
    disclaimer?: ComponentOverrideProps<DisclaimerRenderProps>;
    feedback?: ComponentOverrideProps<FeedbackRenderProps>;
    loading?: ComponentOverrideProps<LoadingRenderProps>;
}
export interface Question {
    value: string;
}
export interface QuestionResponse {
    questions: Array<Question>;
}
export interface SuggestedQuestionsParameters {
    numResults?: number;
    preFilterExpression?: FilterExpression;
}
export interface AnswerRequestParameters {
    preFilterExpression?: FilterExpression;
    guard?: boolean;
    fmtOptions?: Record<string, any>;
}
export interface ApiItemVariation extends Record<string, any> {
    value: string;
    data?: ItemData;
}
export interface ApiItem extends Record<string, any> {
    value: string;
    matched_terms: Array<string>;
    data: ItemData;
    variations?: Array<ApiItemVariation> | null;
    variations_map?: Record<string, any> | Array<Record<string, any>> | null;
}
export interface AnswerItemResults {
    request?: Record<string, any>;
    response: {
        results: Array<ApiItem>;
    };
}
export interface GetAnswerResultsResponse {
    qna_result_id: string;
    value: string;
    item_results?: AnswerItemResults;
    follow_up_questions?: Array<Question>;
    thread_id?: string;
}
