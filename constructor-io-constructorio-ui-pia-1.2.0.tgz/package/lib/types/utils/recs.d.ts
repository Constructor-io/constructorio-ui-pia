import { RecsRefinement, Translations } from '../types';
/**
 * The line that introduces the refinement options. Prefers the prompt the API sent, so our
 * copy and theirs cannot drift.
 */
export declare function resolveRefinementQuestion(refinement: RecsRefinement | null, translations?: Translations): string;
