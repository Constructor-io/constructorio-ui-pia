import { Translations } from '../types';
/**
 * Translates a word using the provided translations object.
 * Falls back to English defaults if translation is not provided.
 *
 * An explicitly empty string is returned as-is: blanking out a string is how
 * consumers hide it.
 *
 * @param word - The key to translate
 * @param translations - Optional user-provided translations object
 * @returns The translated string or the original word if no translation exists
 */
export declare const translate: (word: string, translations?: Translations) => string;
