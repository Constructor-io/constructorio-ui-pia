import { Nullable } from '@constructor-io/constructorio-client-javascript';
import { ApiItem, Formatters, GetAnswerResultsResponse, Item } from '../types';
/**
 * Converts a raw ApiItem from the Get Answers API response into an Item object
 * that can be used in the Carousel component.
 */
export declare function transformResultItem(resultItem: ApiItem, formatImageUrl?: Formatters['formatImageUrl']): Nullable<Item>;
/**
 * Pulls the product results out of an answers response and converts them to Items.
 *
 * Returns `null` rather than an empty array whenever there is nothing to render, so callers
 * can treat "no products" as a single case.
 */
export declare function extractAndTransformItems(data: Nullable<GetAnswerResultsResponse>, formatImageUrl?: Formatters['formatImageUrl']): Array<Item> | null;
